# Project Title

C.F.D.S(Criminal Face Detection System)

## Description

It is used to detect a criminal face by continously senses the environment through the feasible camera input and detects when criminal captured through camera.

### Executing program

* How to run the program

```
cd project
```

```
pip install -r requirements.txt
```

```
python manage.py migrate
```

```
python manage.py makemigrations
```

```
python manage.py runserver
```

### Issues
* If there is an issues to install face recognition then you can follow through this link

```
1.first install dlib (pip install dlib)
2.then install cmake (pip install cmake)
3.install face-recognition (pip install face-recognition)
```

